<?php

/**
 * @file
 * Template for an amp-iframe.
 *
 * Available variables:
 * - iframe: The AMP-processed text which contains the iframe.
 *
 * @see template_preprocess_amp_iframe()
 */
?>
<?php print $iframe; ?>
