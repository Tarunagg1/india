<div class="soundcloudfield-js-embed-wrapper">
  <div id="<?php echo $target; ?>">
  </div>
</div>